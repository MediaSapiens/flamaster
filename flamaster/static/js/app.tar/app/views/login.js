define('views/login', ['backbone', 'underscore', 'jquery'], function(BB, _, $) {
  return BB.View.extend({
    initialize: function() {

    },

    render: function() {
      return this.$el;
    }
  });
});
